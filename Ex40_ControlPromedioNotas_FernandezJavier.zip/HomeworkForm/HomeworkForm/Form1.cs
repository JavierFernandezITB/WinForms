﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Runtime.Intrinsics.X86;
using System.Text;
using System.Text.RegularExpressions;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace HomeworkForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void CalcAvg()
        {
            try
            {
                List<float> notas = new List<float>() {
                    float.Parse(textBoxNota1.Text) ,
                    float.Parse(textBoxNota2.Text),
                    float.Parse(textBoxNota3.Text),
                    float.Parse(textBoxNota4.Text)
                };
                notas.Sort();
                float avg = (notas[0] + notas[1] + notas[2] + notas[3]) / 4;
                labelAvgMark.Text = avg.ToString();
                labelLowestMark.Text = notas[0].ToString();
                labelResultCondition.Text = avg >= 5 ? "PASS" : "FAIL";
            }
            catch
            {
                labelAvgMark.Text = string.Empty;
                labelLowestMark.Text = string.Empty;
                labelResultCondition.Text = string.Empty;
            }
        }

        private void CheckInput(System.Windows.Forms.TextBox textbox)
        {
            if (textbox.Text != string.Empty)
            {
                if (Regex.IsMatch(textbox.Text, "[^0-9,.]"))
                {
                    MessageBox.Show("Solo puedes introducir números en este campo.");
                    textbox.Text = textbox.Text = string.Empty;
                }
                else if (float.Parse(textbox.Text) > 10)
                {
                    MessageBox.Show("Solo puedes introducir números entre 0 y 10 (incluyendo decimales)");
                    textbox.Text = textbox.Text = string.Empty;
                }
            }
        }

        private void textBoxNota1_TextChanged(object sender, EventArgs e)
        {
            CheckInput(textBoxNota1);
            CalcAvg();
        }

        private void textBoxNota2_TextChanged(object sender, EventArgs e)
        {
            CheckInput(textBoxNota2);
            CalcAvg();
        }

        private void textBoxNota3_TextChanged(object sender, EventArgs e)
        {
            CheckInput(textBoxNota3);
            CalcAvg();
        }

        private void textBoxNota4_TextChanged(object sender, EventArgs e)
        {
            CheckInput(textBoxNota4);
            CalcAvg();
        }

        private void buttonCleanFields_Click(object sender, EventArgs e)
        {
            textBoxNota1.Text = string.Empty;
            textBoxNota2.Text = string.Empty;
            textBoxNota3.Text = string.Empty;
            textBoxNota4.Text = string.Empty;
        }

        private void buttonExit_Click(object sender, EventArgs e)
        {
            this.Close();
        }
    }
}
