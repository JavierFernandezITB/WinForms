﻿namespace HomeworkForm
{
    partial class Form1
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            appTitle = new Label();
            labelAlumno = new Label();
            labelRegAlumno = new Label();
            labelNota1 = new Label();
            labelNota2 = new Label();
            labelNota3 = new Label();
            labelNota4 = new Label();
            textBoxNota1 = new TextBox();
            textBoxNota2 = new TextBox();
            textBoxNota3 = new TextBox();
            textBoxNota4 = new TextBox();
            textBoxNombreAlumno = new TextBox();
            buttonCleanFields = new Button();
            buttonExit = new Button();
            labelAVGMsg = new Label();
            labelLowestMSG = new Label();
            labelConditionMSG = new Label();
            labelAvgMark = new Label();
            labelLowestMark = new Label();
            labelResultCondition = new Label();
            label7 = new Label();
            SuspendLayout();
            // 
            // appTitle
            // 
            appTitle.Dock = DockStyle.Top;
            appTitle.Font = new Font("Segoe UI", 9F, FontStyle.Bold, GraphicsUnit.Point, 0);
            appTitle.Location = new Point(0, 10);
            appTitle.Name = "appTitle";
            appTitle.Size = new Size(555, 15);
            appTitle.TabIndex = 0;
            appTitle.Text = "CONTROL PROMEDIO DE NOTAS";
            appTitle.TextAlign = ContentAlignment.TopCenter;
            // 
            // labelAlumno
            // 
            labelAlumno.AutoSize = true;
            labelAlumno.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelAlumno.Location = new Point(16, 73);
            labelAlumno.Name = "labelAlumno";
            labelAlumno.Size = new Size(57, 17);
            labelAlumno.TabIndex = 1;
            labelAlumno.Text = "Alumno";
            // 
            // labelRegAlumno
            // 
            labelRegAlumno.AutoSize = true;
            labelRegAlumno.Font = new Font("Segoe UI", 9.75F, FontStyle.Bold, GraphicsUnit.Point, 0);
            labelRegAlumno.Location = new Point(293, 73);
            labelRegAlumno.Name = "labelRegAlumno";
            labelRegAlumno.Size = new Size(116, 17);
            labelRegAlumno.TabIndex = 2;
            labelRegAlumno.Text = "Registro de notas";
            // 
            // labelNota1
            // 
            labelNota1.AutoSize = true;
            labelNota1.Location = new Point(302, 102);
            labelNota1.Name = "labelNota1";
            labelNota1.Size = new Size(43, 15);
            labelNota1.TabIndex = 3;
            labelNota1.Text = "NOTA1";
            // 
            // labelNota2
            // 
            labelNota2.AutoSize = true;
            labelNota2.Location = new Point(351, 102);
            labelNota2.Name = "labelNota2";
            labelNota2.Size = new Size(43, 15);
            labelNota2.TabIndex = 4;
            labelNota2.Text = "NOTA2";
            // 
            // labelNota3
            // 
            labelNota3.AutoSize = true;
            labelNota3.Location = new Point(400, 102);
            labelNota3.Name = "labelNota3";
            labelNota3.Size = new Size(43, 15);
            labelNota3.TabIndex = 5;
            labelNota3.Text = "NOTA3";
            // 
            // labelNota4
            // 
            labelNota4.AutoSize = true;
            labelNota4.Location = new Point(449, 102);
            labelNota4.Name = "labelNota4";
            labelNota4.Size = new Size(43, 15);
            labelNota4.TabIndex = 6;
            labelNota4.Text = "NOTA4";
            // 
            // textBoxNota1
            // 
            textBoxNota1.BorderStyle = BorderStyle.None;
            textBoxNota1.Location = new Point(302, 120);
            textBoxNota1.Name = "textBoxNota1";
            textBoxNota1.Size = new Size(43, 16);
            textBoxNota1.TabIndex = 7;
            textBoxNota1.TextAlign = HorizontalAlignment.Center;
            textBoxNota1.TextChanged += textBoxNota1_TextChanged;
            // 
            // textBoxNota2
            // 
            textBoxNota2.BorderStyle = BorderStyle.None;
            textBoxNota2.Location = new Point(351, 120);
            textBoxNota2.Name = "textBoxNota2";
            textBoxNota2.Size = new Size(43, 16);
            textBoxNota2.TabIndex = 8;
            textBoxNota2.TextAlign = HorizontalAlignment.Center;
            textBoxNota2.TextChanged += textBoxNota2_TextChanged;
            // 
            // textBoxNota3
            // 
            textBoxNota3.BorderStyle = BorderStyle.None;
            textBoxNota3.Location = new Point(400, 120);
            textBoxNota3.Name = "textBoxNota3";
            textBoxNota3.Size = new Size(43, 16);
            textBoxNota3.TabIndex = 9;
            textBoxNota3.TextAlign = HorizontalAlignment.Center;
            textBoxNota3.TextChanged += textBoxNota3_TextChanged;
            // 
            // textBoxNota4
            // 
            textBoxNota4.BorderStyle = BorderStyle.None;
            textBoxNota4.Location = new Point(449, 120);
            textBoxNota4.Name = "textBoxNota4";
            textBoxNota4.Size = new Size(43, 16);
            textBoxNota4.TabIndex = 10;
            textBoxNota4.TextAlign = HorizontalAlignment.Center;
            textBoxNota4.TextChanged += textBoxNota4_TextChanged;
            // 
            // textBoxNombreAlumno
            // 
            textBoxNombreAlumno.BorderStyle = BorderStyle.None;
            textBoxNombreAlumno.Location = new Point(16, 120);
            textBoxNombreAlumno.Name = "textBoxNombreAlumno";
            textBoxNombreAlumno.Size = new Size(208, 16);
            textBoxNombreAlumno.TabIndex = 11;
            // 
            // buttonCleanFields
            // 
            buttonCleanFields.Location = new Point(449, 180);
            buttonCleanFields.Name = "buttonCleanFields";
            buttonCleanFields.Size = new Size(96, 23);
            buttonCleanFields.TabIndex = 13;
            buttonCleanFields.Text = "Limpiar";
            buttonCleanFields.UseVisualStyleBackColor = true;
            buttonCleanFields.Click += buttonCleanFields_Click;
            // 
            // buttonExit
            // 
            buttonExit.Location = new Point(449, 209);
            buttonExit.Name = "buttonExit";
            buttonExit.Size = new Size(96, 23);
            buttonExit.TabIndex = 14;
            buttonExit.Text = "Salir";
            buttonExit.UseVisualStyleBackColor = true;
            buttonExit.Click += buttonExit_Click;
            // 
            // labelAVGMsg
            // 
            labelAVGMsg.AutoSize = true;
            labelAVGMsg.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelAVGMsg.Location = new Point(16, 150);
            labelAVGMsg.Name = "labelAVGMsg";
            labelAVGMsg.Size = new Size(138, 17);
            labelAVGMsg.TabIndex = 15;
            labelAVGMsg.Text = "PROMEDIO DE NOTAS";
            // 
            // labelLowestMSG
            // 
            labelLowestMSG.AutoSize = true;
            labelLowestMSG.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelLowestMSG.Location = new Point(16, 178);
            labelLowestMSG.Name = "labelLowestMSG";
            labelLowestMSG.Size = new Size(105, 17);
            labelLowestMSG.TabIndex = 16;
            labelLowestMSG.Text = "NOTA MÁS BAJA";
            // 
            // labelConditionMSG
            // 
            labelConditionMSG.AutoSize = true;
            labelConditionMSG.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelConditionMSG.Location = new Point(16, 209);
            labelConditionMSG.Name = "labelConditionMSG";
            labelConditionMSG.Size = new Size(79, 17);
            labelConditionMSG.TabIndex = 17;
            labelConditionMSG.Text = "CONDICIÓN";
            // 
            // labelAvgMark
            // 
            labelAvgMark.BackColor = SystemColors.Window;
            labelAvgMark.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelAvgMark.Location = new Point(199, 150);
            labelAvgMark.Name = "labelAvgMark";
            labelAvgMark.Size = new Size(26, 17);
            labelAvgMark.TabIndex = 18;
            labelAvgMark.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labelLowestMark
            // 
            labelLowestMark.BackColor = SystemColors.Window;
            labelLowestMark.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelLowestMark.Location = new Point(199, 178);
            labelLowestMark.Name = "labelLowestMark";
            labelLowestMark.Size = new Size(26, 17);
            labelLowestMark.TabIndex = 19;
            labelLowestMark.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // labelResultCondition
            // 
            labelResultCondition.BackColor = SystemColors.Window;
            labelResultCondition.Font = new Font("Segoe UI", 9.75F, FontStyle.Regular, GraphicsUnit.Point, 0);
            labelResultCondition.Location = new Point(185, 209);
            labelResultCondition.Name = "labelResultCondition";
            labelResultCondition.Size = new Size(40, 17);
            labelResultCondition.TabIndex = 20;
            labelResultCondition.TextAlign = ContentAlignment.MiddleCenter;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Location = new Point(16, 102);
            label7.Name = "label7";
            label7.Size = new Size(178, 15);
            label7.TabIndex = 21;
            label7.Text = "Introduce el nombre del alumno";
            // 
            // Form1
            // 
            AutoScaleDimensions = new SizeF(7F, 15F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(555, 242);
            Controls.Add(label7);
            Controls.Add(labelResultCondition);
            Controls.Add(labelLowestMark);
            Controls.Add(labelAvgMark);
            Controls.Add(labelConditionMSG);
            Controls.Add(labelLowestMSG);
            Controls.Add(labelAVGMsg);
            Controls.Add(buttonExit);
            Controls.Add(buttonCleanFields);
            Controls.Add(textBoxNombreAlumno);
            Controls.Add(textBoxNota4);
            Controls.Add(textBoxNota3);
            Controls.Add(textBoxNota2);
            Controls.Add(textBoxNota1);
            Controls.Add(labelNota4);
            Controls.Add(labelNota3);
            Controls.Add(labelNota2);
            Controls.Add(labelNota1);
            Controls.Add(labelRegAlumno);
            Controls.Add(labelAlumno);
            Controls.Add(appTitle);
            MaximizeBox = false;
            Name = "Form1";
            Padding = new Padding(0, 10, 0, 0);
            ShowIcon = false;
            StartPosition = FormStartPosition.CenterParent;
            Text = "Control de notas";
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Label appTitle;
        private Label labelAlumno;
        private Label labelRegAlumno;
        private Label labelNota1;
        private Label labelNota2;
        private Label labelNota3;
        private Label labelNota4;
        private TextBox textBoxNota1;
        private TextBox textBoxNota2;
        private TextBox textBoxNota3;
        private TextBox textBoxNota4;
        private TextBox textBoxNombreAlumno;
        private Button buttonCleanFields;
        private Button buttonExit;
        private Label labelAVGMsg;
        private Label labelLowestMSG;
        private Label labelConditionMSG;
        private Label labelAvgMark;
        private Label labelLowestMark;
        private Label labelResultCondition;
        private Label label7;
    }
}