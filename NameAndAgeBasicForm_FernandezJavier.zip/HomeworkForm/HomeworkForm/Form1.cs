using System.Text.RegularExpressions;

namespace HomeworkForm
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            Regex check = new Regex("^[A-Za-z]+$");
            string name = textBox1.Text;
            if (name == "" || !check.IsMatch(name))
            {
                errorProvider1.SetError(this.textBox1, "Introduce un nombre valido pedazo de vago >:(");
            }
            else
            {
                try
                {
                    int age = int.Parse(textBox2.Text);
                    if (age <= 0)
                    {
                        errorProvider1.SetError(this.textBox2, "Naciste ayer o que bro?");
                    } else
                    {
                        errorProvider1.Clear();
                        MessageBox.Show($"Hola! {name} de {age} a�os.");
                    }
                }
                catch
                {
                    errorProvider1.SetError(this.textBox2, "n�o n�o amig�o");
                }
            }
        }
    }
}
